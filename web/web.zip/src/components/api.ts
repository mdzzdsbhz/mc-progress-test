import axios from 'axios'

export const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000'

export const api = axios.create({
  baseURL: API_BASE,
})

export async function listItems(params?: { q?: string; category?: string }) {
  const { data } = await api.get('/api/items', { params })
  return data
}

export async function uploadIcon(file: File, meta?: { name?: string; category?: string; description?: string }) {
  const form = new FormData()
  form.append('file', file)
  if (meta?.name) form.append('name', meta.name)
  if (meta?.category) form.append('category', meta.category)
  if (meta?.description) form.append('description', meta.description)
  const { data } = await api.post('/api/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } })
  return data
}

export async function listScenes() {
  const { data } = await api.get('/api/scenes')
  return data
}

export async function createScene(name: string) {
  const form = new FormData()
  form.append('name', name)
  const { data } = await api.post('/api/scenes', form)
  return data
}

export async function getGraph(sceneId: number) {
  const { data } = await api.get(`/api/scenes/${sceneId}/graph`)
  return data
}

export async function saveGraph(sceneId: number, payload: any) {
  const { data } = await api.put(`/api/scenes/${sceneId}/graph`, payload)
  return data
}

export async function edgeStyles() {
  const { data } = await api.get('/api/edge-styles')
  return data
}
