import React, { useEffect, useMemo, useState } from 'react'
import Inventory from './Inventory'
import Canvas from './Canvas'
import Toolbar from './Toolbar'
import { listScenes, createScene, getGraph, saveGraph } from './api'

type Scene = { id: number; name: string }

export default function App() {
  const [scenes, setScenes] = useState<Scene[]>([])
  const [sceneId, setSceneId] = useState<number | null>(null)
  const [pending, setPending] = useState(false)
  const [graph, setGraph] = useState<any>({ nodes: [], edges: [], meta: {} })

  useEffect(() => {
    (async () => {
      const s = await listScenes()
      setScenes(s)
      if (s.length) setSceneId(s[0].id)
    })()
  }, [])

  useEffect(() => {
    if (sceneId == null) return
    ;(async () => {
      const g = await getGraph(sceneId)
      setGraph(g)
    })()
  }, [sceneId])

  async function onSave(g: any) {
    if (sceneId == null) return
    setPending(true)
    try {
      const res = await saveGraph(sceneId, g)
      setGraph(res)
    } finally {
      setPending(false)
    }
  }

  async function onCreateScene() {
    const name = prompt('新建场景名称？')
    if (!name) return
    const s = await createScene(name)
    const all = await listScenes()
    setScenes(all)
    setSceneId(s.id)
  }

  return (
    <div className="app-shell">
      <Toolbar
        scenes={scenes}
        sceneId={sceneId}
        onSceneChange={(id) => setSceneId(id)}
        onCreateScene={onCreateScene}
        onSave={() => onSave(graph)}
        saving={pending}
      />
      <div className="layout">
        <div className="sidebar">
          <Inventory />
          <div style={{marginTop: 12, fontSize: 12, color: '#6b7280'}}>
            提示：支持把图片文件直接拖到物品库面板，自动上传为图标。
          </div>
        </div>
        <div className="canvas-wrap">
          <Canvas
            key={sceneId ?? 0}
            initialGraph={graph}
            onGraphChange={(g) => setGraph(g)}
          />
        </div>
      </div>
    </div>
  )
}
