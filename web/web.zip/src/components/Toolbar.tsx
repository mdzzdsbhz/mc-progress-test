import React from 'react'

export default function Toolbar({ scenes, sceneId, onSceneChange, onCreateScene, onSave, saving }:
  { scenes: {id:number; name:string}[], sceneId: number|null, onSceneChange: (id:number)=>void, onCreateScene: ()=>void, onSave: ()=>void, saving: boolean }) {
  return (
    <div className="toolbar">
      <div style={{fontWeight: 700}}>MC 进度系统 WebUI</div>
      <div className="sep"></div>
      <span>场景：</span>
      <select className="btn" value={sceneId ?? ''} onChange={e => onSceneChange(Number(e.target.value))}>
        {scenes.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
      </select>
      <button className="btn" onClick={onCreateScene}>新建场景</button>
      <div className="sep"></div>
      <button className="btn primary" onClick={onSave} disabled={saving}>{saving ? '保存中…' : '保存到后端'}</button>
      <div className="sep"></div>
      <div style={{fontSize: 12, color: '#6b7280'}}>快捷键：<span className="kbd">Delete</span> 删除、鼠标框选、多选拖拽、拖线改变指向</div>
    </div>
  )
}
